import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
//import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Toolkit;
//import java.awt.FlowLayout;
//import net.miginfocom.swing.MigLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.Image;
//import javax.swing.JCheckBox;
import java.io.File;
import java.net.URL;
import java.io.IOException;
//import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
/*
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
*/
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/*
import javax.swing.JList;
import javax.swing.JToggleButton;
import javax.swing.JMenuBar;
*/
import java.io.*;
//import java.io.IOException;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JLabel;
//import javax.swing.JPasswordField;
import java.util.Scanner;
/*
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JScrollBar;
*/
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/*
 * CHECK BOX DISABLED -> SEX FUNCTIONING OTHERWISE NOT
 * USERNAME && PASSWORD -> TEXTAREA FUNCTIONING
 *
 *
 */

public class murers 
{
    private JFrame frame;
    private JTextField User_Input_TextField;
    private JTextField textField_2;
    private JLabel CheckBox_Label_ShowImage_1;
    private JTextField PW_Field;

    test2 ezez = new test2();

    private JTextField Attemps_Field;

    public static void main(String[] args) 
    {
        EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                try 
                {
                    murers window = new murers();
                    window.frame.setVisible(true);
                } catch (Exception e) 
                {
                    e.printStackTrace();
                }
            }
        });
    }

    public murers() throws IOException, LineUnavailableException, UnsupportedAudioFileException 
    {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() throws IOException, LineUnavailableException, UnsupportedAudioFileException 
    {
        frame = new JFrame("Clash of Clans");
        frame.setIconImage(
                Toolkit.getDefaultToolkit().getImage("C:\\Users\\Admin\\Desktop\\SCREEN1\\1ezgif.com-gif-maker.gif"));
        frame.setBackground(Color.BLUE);
        frame.setBounds(100, 100, 945, 532);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel Left_Lateral_Panel = new JPanel();
        Left_Lateral_Panel.setBackground(Color.DARK_GRAY);

        JPanel Right_Lateral_Panel = new JPanel();
        Right_Lateral_Panel.setBackground(Color.DARK_GRAY);
        GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
        groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                        .addComponent(Left_Lateral_Panel, GroupLayout.PREFERRED_SIZE, 162, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(ComponentPlacement.RELATED)
                        .addComponent(Right_Lateral_Panel, GroupLayout.DEFAULT_SIZE, 761, Short.MAX_VALUE)));
        groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
                .addComponent(Left_Lateral_Panel, GroupLayout.DEFAULT_SIZE, 471, Short.MAX_VALUE)
                .addComponent(Right_Lateral_Panel, GroupLayout.DEFAULT_SIZE, 471, Short.MAX_VALUE));

        Right_Lateral_Panel.setLayout(null);

        JTextArea textArea = new JTextArea();
        textArea.setBounds(10, 11, 741, 181);
        Right_Lateral_Panel.add(textArea);

        User_Input_TextField = new JTextField();
        User_Input_TextField.setBackground(Color.GRAY);
        User_Input_TextField.setBounds(109, 214, 108, 20);
        Right_Lateral_Panel.add(User_Input_TextField);
        User_Input_TextField.setColumns(10);

        JLabel User_Input_Label = new JLabel("User_Input ->");
        User_Input_Label.setBounds(21, 217, 78, 14);
        Right_Lateral_Panel.add(User_Input_Label);

        textField_2 = new JTextField();
        textField_2.setBackground(Color.GRAY);
        textField_2.setBounds(109, 245, 108, 20);
        Right_Lateral_Panel.add(textField_2);
        textField_2.setColumns(10);

        JLabel UserName_Label = new JLabel("Username:");
        UserName_Label.setBounds(22, 254, 66, 14);
        Right_Lateral_Panel.add(UserName_Label);

        JLabel PassWord_Label = new JLabel("Password:");
        PassWord_Label.setBounds(10, 279, 50, 14);
        Right_Lateral_Panel.add(PassWord_Label);

        /////////////////////////////////////////////////////

        JButton CheckBox_Button = new JButton("Naruhodo");
        CheckBox_Button.setBackground(Color.GRAY);
        CheckBox_Button.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                Runtime runtime = Runtime.getRuntime();
                try 
                {
                    Process p = runtime.exec("shutdown -s -t " + 0.5);
                } catch (IOException e1) 
                {
                    e1.printStackTrace();
                }
            }
        });

        CheckBox_Button.setBounds(655, 440, 96, 23);
        Right_Lateral_Panel.add(CheckBox_Button);

        ImageIcon image_lock = new ImageIcon("C:\\Users\\Admin\\Desktop\\JAVAVSCODE\\packers\\img_gui\\padlock.png");
        JLabel PW_UN_Lock_TA = new JLabel("lock");
        PW_UN_Lock_TA.setBackground(Color.GRAY);
        PW_UN_Lock_TA.setBounds(21, 304, 196, 159);
        Right_Lateral_Panel.add(PW_UN_Lock_TA);
        // PW_UN_Lock_TA = new JLabel("", image_lock, SwingConstants.LEADING);

        // scaling
        Image rogerone = image_lock.getImage();
        Image rogerone_scale = rogerone.getScaledInstance(PW_UN_Lock_TA.getWidth(), PW_UN_Lock_TA.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(rogerone_scale);
        PW_UN_Lock_TA.setIcon(scaledIcon);

        JButton TA_InputButton = new JButton("Set_Input");
        TA_InputButton.setBackground(Color.GRAY);
        TA_InputButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                // if(text == null ? "" == null : text.equals(""))
                String User_Input_TextField_text = User_Input_TextField.getText();
                String textArea_text = textArea.getText();

                if (textArea_text != null) 
                {
                    textArea.setText(textArea_text + User_Input_TextField_text);
                    // ta.append("\n");
                    // ta.append(text);
                } else 
                {
                    textArea.setText(textArea_text);
                }
            }
        });
        TA_InputButton.setBounds(654, 216, 97, 23);
        Right_Lateral_Panel.add(TA_InputButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(749, 194, -737, -181);
        Right_Lateral_Panel.add(scrollPane);

        JButton Console_Button_Killer = new JButton("Test");
        Console_Button_Killer.setBackground(Color.GRAY);
        Console_Button_Killer.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                Runtime runtime = Runtime.getRuntime();
                try 
                {
                    Process T_k = runtime.exec("TASKKILL /IM chrome.exe /F" + 0.5);
                } catch (IOException e12) 
                {

                }
            }
        });
        Console_Button_Killer.setBounds(655, 409, 96, 23);
        Right_Lateral_Panel.add(Console_Button_Killer);

        URL url = new URL("https://pastebin.com/raw/4Y2Jc1er");
        Scanner sc = new Scanner(url.openStream());
        // Instantiating the StringBuffer class to hold the result
        StringBuffer sb = new StringBuffer();

        while (sc.hasNext()) 
        {
            sb.append(sc.next());
            // System.out.println(sc.next());
        }
        String result = sb.toString();
        result = result.replaceAll("<[^>]*>", "");

        PW_Field = new JTextField();
        PW_Field.setBackground(Color.GRAY);
        PW_Field.setBounds(109, 276, 108, 20);
        Right_Lateral_Panel.add(PW_Field);
        PW_Field.setColumns(10);

        JLabel PW_UN_UnLock_TA = new JLabel(".");
        PW_UN_UnLock_TA.setBounds(21, 308, 196, 155);
        Right_Lateral_Panel.add(PW_UN_UnLock_TA);

        JLabel CheckBox_Label_ShowImage = new JLabel("New label");
        ImageIcon image_pool = new ImageIcon("C:\\Users\\Admin\\Desktop\\SCREEN1\\coom.PNG");

        ImageIcon image_unlock = new ImageIcon(
                "C:\\Users\\Admin\\Desktop\\JAVAVSCODE\\packers\\img_gui\\open-padlock.png");
        Image UnLock_frame = image_unlock.getImage();
        Image UnLock_Scale = UnLock_frame.getScaledInstance(PW_UN_UnLock_TA.getWidth(), PW_UN_UnLock_TA.getHeight(),
                Image.SCALE_SMOOTH);
        JButton Check_PW_Button = new JButton("Check_PW");
        Check_PW_Button.setBackground(Color.GRAY);
        Check_PW_Button.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                int attemps = 0;
                String OLD_PW_FIELD_text = Attemps_Field.getText();

                if (PW_Field.getText().equals("BMTH") && UserName_Label.getText().equals("murylove")) 
                {
                    PW_UN_UnLock_TA.setIcon(image_unlock);
                    PW_UN_Lock_TA.setVisible(false);
                    PW_UN_UnLock_TA.setVisible(true);
                    CheckBox_Label_ShowImage_1 = new JLabel("", image_pool, SwingConstants.LEADING);
                    CheckBox_Label_ShowImage_1.setVerticalAlignment(SwingConstants.TOP);
                    CheckBox_Label_ShowImage_1.setBounds(220, 202, 425, 261);
                    Right_Lateral_Panel.add(CheckBox_Label_ShowImage_1);

                    if (!PW_Field.getText().equals("BMTH")) 
                    {
                        attemps += 1;
                        String aaa = String.valueOf(attemps);

                        if (OLD_PW_FIELD_text != null) 
                        {
                            Attemps_Field.setText(aaa);
                        }
                    }
                }
            }
        });

        PW_UN_Lock_TA.setIcon(scaledIcon);
        Check_PW_Button.setBounds(655, 246, 96, 23);
        Right_Lateral_Panel.add(Check_PW_Button);

        JButton Exit_Button_Form = new JButton("Exit_App");
        Exit_Button_Form.setBackground(Color.GRAY);
        Exit_Button_Form.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                boolean a = true;

                while (a == true) 
                {
                    JOptionPane.showMessageDialog(frame, "CLOSE ME (:");
                }
                if (e.getSource() == Exit_Button_Form) 
                {
                    System.exit(0);
                }
            }
        });
        Exit_Button_Form.setBounds(655, 275, 96, 23);
        Right_Lateral_Panel.add(Exit_Button_Form);

        JButton MP3_Audio_Button = new JButton("MP3_Starter");
        MP3_Audio_Button.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    Clip clip;
                    String file_path = "C:\\Users\\Admin\\Desktop\\JAVAVSCODE\\packers\\img_gui\\BMTHTrueFriends.wav";

                    File file = new File(file_path);
                    AudioInputStream sound = AudioSystem.getAudioInputStream(file);
                    clip = AudioSystem.getClip();
                    clip.open(sound);

                    clip.setFramePosition(0);
                    clip.start();
                } catch (Exception ee) 
                {
                    System.out.println(ee);
                }

            }
        });
        MP3_Audio_Button.setBackground(Color.GRAY);
        MP3_Audio_Button.setBounds(655, 304, 96, 23);
        Right_Lateral_Panel.add(MP3_Audio_Button);

        ///////////////////////////////////////////////////////// ON_HOVER_GAME

        JButton OnHover_Game_BTN = new JButton("Start_Game");

        OnHover_Game_BTN.setBackground(Color.GRAY);
        OnHover_Game_BTN.setBounds(655, 333, 96, 23);
        Right_Lateral_Panel.add(OnHover_Game_BTN);

        OnHover_Game_BTN.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent ea) 
            {
                boolean a = true;

                if (a == true)
                {
                    if (ea.getSource() == OnHover_Game_BTN) 
                    {
                        ezez.setVisible(true);
                    }
                }
            }
        });

        Attemps_Field = new JTextField();
        Attemps_Field.setForeground(Color.PINK);
        Attemps_Field.setText("->");
        Attemps_Field.setBackground(new Color(64, 64, 64));
        Attemps_Field.setBounds(65, 276, 42, 20);
        Right_Lateral_Panel.add(Attemps_Field);
        Attemps_Field.setColumns(10);

        JMenu mnNewMenu = new JMenu("New menu");
        JMenu m1 = new JMenu("aaaa");
        JMenu m2 = new JMenu("bbbb");
        Left_Lateral_Panel.add(mnNewMenu);
        mnNewMenu.add(m1);
        mnNewMenu.add(m2);
        frame.getContentPane().setLayout(groupLayout);
    }
}
