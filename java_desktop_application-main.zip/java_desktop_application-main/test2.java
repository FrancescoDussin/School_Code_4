import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Window.Type;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class test2 extends JPanel 
{
    public long myLong = 10;

    Random sandu = new Random();

    // position and dimension
    //int x22 = 0, y22 = 0, width22 = 200, height22 = 200;
    //Color drawColor22 = Color.BLACK;

    KeyEvent ekey;
    private JPanel contentPane;

    public test2() 
    {
        Scanner Mury = new Scanner(System.in);

        setBackground(Color.WHITE);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 804, 445);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);

        //JLabel lblNewLabel = new JLabel(".");
        //ImageIcon image_pool = new ImageIcon("C:\\Users\\Admin\\Desktop\\SCREEN1\\coom.PNG");
        //lblNewLabel.setIcon(image_pool);

        boolean a = true;
        int looper = 0;
        int b = 0;
/*
        repaint();

        ActionListener action_Sex = new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                Color color = new Color(sandu.nextInt(256), sandu.nextInt(256), sandu.nextInt(256));

                drawColor22 = color;
                test2.this.repaint();
            }
        };

        Timer t = new Timer(action_Sex, 500);
    
        //t.setRepeats(true);
        //t.setInitialDelay(0);
        t.start();
*/

        test2 gay = new test2();
        // https://stackoverflow.com/questions/9413656/how-to-use-timer-class-to-call-a-method-do-something-reset-timer-repeat

        Timer lulz = new Timer();
        lulz.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                gay.Sandu_Color();
            }
        },0 , gay.myLong);
    }

    public static void main(String[] args) 
    {
        EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                try 
                {
                    final test2 frame = new test2();
                    frame.setVisible(true);
                } catch (Exception e) 
                {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setContentPane(JPanel contentPane2) 
    {
        //extends JPanel not JFrame
    }

    public void massive_gay()
    {
        
        JPanel panel = new JPanel();
        //panel.setBackground(Color.WHITE);
        //contentPane.add(panel, BorderLayout.CENTER);

        panel.setBackground(Sandu_Color());

        contentPane.add(panel, BorderLayout.CENTER);
        //panel.add(); // lblNewLabel
    }
    public Color Sandu_Color() 
    {
        int Red_Color = (int) (Math.random() * 256);
        int Blue_Color = (int) (Math.random() * 256);
        int Green_Color = (int) (Math.random() * 256);

        return (new Color(Red_Color, Blue_Color, Green_Color));
    }

/*
    @Override
    public void paintComponent(Graphics g) 
    {
        // Overwriting of old picture
        super.paintComponent(g);

        // Draw boundary of circle
        g.setColor(drawColor22);
        g.drawArc(x22, y22, width22, height22, 0, 360);
    }
    */
/*
    public void keyPressed(KeyEvent ekey) 
    {
        if (ekey.getKeyCode() == KeyEvent.VK_F2)
        {
            System.exit(0);
        }   
    }
*/
}
