#dictionary ->
contatto1 = {

    "nome":"yes",
    "cognome":"no",
    "eta":"222"
}

contatto2 = {

    "nome":"yes",
    "cognome":"no",
    "eta":"222"
}

rubrica = [contatto1, contatto2]
#rubrica[1] -> contatto2

#tupla
a = (1,2,3)

#tupla di un singolo elemento 
b = (2,)
#int
b = (2)

