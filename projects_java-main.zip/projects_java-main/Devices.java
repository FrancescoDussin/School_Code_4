/*
Facoltativo per NATALE: es. OOP (ex Verifica)
Un dispositivo è un pc , uno smartphone o un tablet,
che è attivo se ha impostato un orario di accensione 
(hh, mm e ss, di tipo intero) ed un metodo accendi().

Un pc è attivo se ha anche associato il sistema operativo 
selezionato in fase di boot (una stringa tipo "Windows 10" 
oppure "Ubuntu 16.04", ecc.; stringa nulla se non è attivo) 
e la disponibilità del metodo arresta() per spegnerlo.
Deve essere richiamabile anche il metodo hwInfo() 
per mostrare le caratteristiche principali del pc à
(processore,ram, memoria di massa).

Uno smartphone è attivo se è agganciato alla rete 4G o al wi-fi
(una stringa determinerà il tipo di connessione,
stringa nulla se è fuori rete) e la disponibilità del metodo aereo()
per metterlo offline. Deve essere richiamabile anche il metodo hwInfo()
per mostrare le caratteristiche principali (processore, ram, rom).

Un tablet ha caratteristiche sia di pc che di smartphone.


Organizzare opportunamente con delle classi il codice di un dispositivo
che permetta all’utente (anche contemporaneamente) di accendere un pc,
uno smartphone o un tablet, ottenere informazioni su tutte 
le caratteristiche ad esso associate a patto che sia acceso.
Aggiungere, dove si ritiene opportuno, altri metodi e/o campi
per gestire correttamente l'oggetto in questione.
 */

package devices;

import java.text.SimpleDateFormat;  
import java.util.Date;  

import java.util.*;

public class Devices {
    
    컴퓨터 pc;

    public static void main(String[] args) {

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
        Date date = new Date();  
        System.out.println(formatter.format(date));
        
        String ccase = "";
        String ccpu = "";
        String cgpu = "";
        String cram = "";
        String cmotherboard = "";
        String cfans = "";
        String chdd = "";
        String cssd = "";
        String cOSW = "";
        String cOSL = "";
        
        컴퓨터 pc = new 컴퓨터(ccase, ccpu, cgpu, cram, cmotherboard, cfans, chdd, cssd, cOSW, cOSL);
        핸드폰 cp = new 핸드폰();
        태블릿 tb = new 태블릿();
        
        
        
    }
    
    public void IsPcOn() {
        
        if(pc.getcOn() == true && ) {
            
            
        }
        
        if() {
            
            
        } else {
            
            System.out.println("bring me to the horizon - no OS detected");
        }
    }
    
    public void IsCpOn() {
        
        if() {
            
            
        }
        
        if() {
            
            
        } else {
            
            System.out.println("bring me to the horizon - no OS detected");
        }
        
    }
        
    public void IsTbOn() {
        
        if() {
            
            
        }
        
        if() {
            
            
        } else {
            
            System.out.println("bring me to the horizon - no OS detected");
        }
    }
}
