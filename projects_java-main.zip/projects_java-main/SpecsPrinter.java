package devices;

public interface SpecsPrinter {
    
    public void printspecs();
}
