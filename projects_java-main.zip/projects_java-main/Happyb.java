package happyb;

import java.util.Scanner;

public class Happyb {
    
    Scanner searching = new Scanner(System.in);

    private Node head;
    private int elements;

    public Happyb() {

        head = null;
        elements = 0;
    }

    private Node createnodenode(invitati person, Node link) {

        Node newNode = new Node(person);
        newNode.setLink(link);
        
        return newNode;
    }

    public void headAdding(invitati person) {
        
        Node personn = createnodenode(person, head);
        head = personn;
        elements++;
        
        return;
    }

    public void visit() {
        
        Node p = head;
        
        while (p != null) {
            
            System.out.println(p.getInfo());
            p = p.getLink();
        }
    }
/*
    public void tailAdding(invitati person) {
        
        Node p = head;
        Node personn = createnodenode(person, head);
        
        if (head == null) {
            
            headAdding(person);
        } else {
            
            while (p.getLink() != null) {
                p = p.getLink();
                
            }
            
            personn.setLink(null);
            p.setLink(personn);
            elements++;
        }
    }

    private Node getLinkPosition(int position) {
        
        int n = 1;
        Node p = head;
        
        if (head == null) {
            
            System.out.println("Lista vuota");
            return null;
        }
        if ((position > elements) || (position < 1)) {
            
            System.out.println("Posizione errata");
            return null;
        }

        while ((p.getLink() != null) && (n < position)) {
            
            p = p.getLink();
            n++;
        }
        
        return p;
    }

    public void insertposition(invitati person, int position) {
        
        if (position <= 1) {
            
            headAdding(person);
        }
        else if (position == elements + 1) {
            
            tailAdding(person);
        }
        else if (position > elements) {
            
            System.out.println("imposssibile aggiungere"
                    + " elemento in posizione " + position);
            return;
            
        } else {
            
            Node p = getLinkPosition(position - 1);
            p.setLink(createnodenode(person, p.getLink()));
            elements++;
        }
    }

    public void headDelete() {
        
        if (head == null) {
            
            System.out.println("Lista vuota");
        } else {
            
            head = head.getLink();
            elements--;
        }
    }

    public void tailDelete() {
        
        if (head == null) {
            
            System.out.println("Lista vuota");
        } else {
            
            Node p = getLinkPosition(elements - 1);
            p.setLink(null);
            elements--;
        }
    }

    public void PositionDel(int position) {
        
        if (position == 1) {
            
            headDelete();
        } else if (position == elements) {
            
            tailDelete();
        } else {
            
            Node ps = getLinkPosition(position);
            Node pp = getLinkPosition(position - 1);
            pp.setLink(ps.getLink());
            elements--;
        }
        
        return;
    }
    */
        public invitati ricercarobaname (String CercaNome) {
            
        Node p = head;

        while((p != null) && (!p.getInfo().getName().equals(CercaNome))) {

            p= p.getLink();
        }

        return p.getInfo();
    }

    public invitati ricercarobasex (String CercaSex) {
            
        Node p = head;

        while((p != null) && (!p.getInfo().getSex().equals(CercaSex))) {

            p= p.getLink();
        }
        
        return p.getInfo();
    }
                
    public invitati ricercarobacell (String CercaCell) {
            
        Node p = head;

        while((p != null) && (!CercaCell.equals(p.getInfo().getNumT()))) {

            p= p.getLink();
        }
        
        return p.getInfo();
    }
    
    public invitati hasAccepted (char roger) {
        
        Node p = head;
        char coding;
        char n;
        
        System.out.println("ARE YOU ON THE LIST?");
        //coding = searching.nextLine();
        
        //coding = p.getInfo().contains(n);
        
        if (Character.isLetter(roger)) {          //(roger.equals(p.getInfo().getAccepted())) {

            System.out.println("ggggggggggggggggg");
            //p= p.getLink();
        }
        /*
        if(coding == 'y') {
            
            System.out.println("YOU JUST MADE THE LIST");
        } else {
            
            System.out.println("ded");
        }
        */
        return p.getInfo();
    }
}