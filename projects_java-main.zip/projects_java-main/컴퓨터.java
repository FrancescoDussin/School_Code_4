package devices;

public class 컴퓨터 { //computer
    
    private String ccase;
    private String ccpu;
    private String cgpu;
    private String cram;
    private String cmotherboard;
    private String cfans;
    private String chdd;
    private String cssd;
    
    private Boolean ONNER;
    private String cOSW;
    private String cOSL;

    public 컴퓨터(String ccase, String ccpu, String cgpu, String cram, String cmotherboard, String cfans, String chdd, String cssd, String cOSW, String cOSL) {
        
        this.ccase = "corsair";
        this.ccpu = "ryzen7";
        this.cgpu = "rx5700";
        this.cram = "corsair";
        this.cmotherboard = "asus";
        this.cfans = "corsair";
        this.chdd = "seagate";
        this.cssd = "crucial";
        this.cOSW = "windows";
        this.cOSL = "linux";
    }

    public String getCcase() {
        
        return ccase;
    }

    public void setCcase(String ccase) {
        
        this.ccase = ccase;
    }
    
    ///////////////////////////////////

    public String getcCpu() {
        
        return ccpu;
    }

    public void setcCpu(String ccpu) {
        
        this.ccpu = ccpu;
    }
    
    ///////////////////////////////////

    public String getcGpu() {
        
        return cgpu;
    }

    public void setcGpu(String cgpu) {
        
        this.cgpu = cgpu;
    }
    
    ///////////////////////////////////

    public String getcRam() {
        
        return cram;
    }

    public void setcRam(String cram) {
        
        this.cram = cram;
    }
    
    ///////////////////////////////////

    public String getcMotherboard() {
        
        return cmotherboard;
    }

    public void setcMotherboard(String cmotherboard) {
        
        this.cmotherboard = cmotherboard;
    }
    
    ///////////////////////////////////

    public String getcFans() {
        
        return cfans;
    }

    public void setFans(String cfans) {
        
        this.cfans = cfans;
    }

    ///////////////////////////////////
    
    public String getcHdd() {
        
        return chdd;
    }

    public void setHdd(String chdd) {
        
        this.chdd = chdd;
    }
    
    ///////////////////////////////////

    public String getcSsd() {
        
        return cssd;
    }

    public void setcSsd(String cssd) {
        
        this.cssd = cssd;
    }
    
    ///////////////////////////////////
    
    public void turncOn(String OperativeSys) throws InterruptedException {
        
        cOSW = OperativeSys;
        cOSL = OperativeSys;
        ONNER = true;
        
        System.out.println(""
          + "Do you wanna start a cult with me?\n" +
            "I'm not vibrating like I ought to be\n" +
            "I need a purpose, I can't keep surfing\n" +
            "Through this existential misery\n" +
            "Now we're gonna need some real estate\n" +
            "But if I choose my words carefully\n" +
            "Think I could fool you that I'm the guru?\n" +
            "Wait, how do you spell epiphany?\n" +
            "Before the truth will set you free, it'll piss you off\n" +
            "Before you find a place to be, you're gonna lose the plot\n" +
            "Too late to tell you now, one ear and right out the other one\n" +
            "'Cause all you ever do is chant the same old mantra\n" +
            "Yeah\n" +
            "Could I have your attention, please?\n" +
            "It's time to tap into your tragedy\n" +
            "Think you could use a new abuser\n" +
            "Close your eyes and listen carefully\n" +
            "Imagine you're stood on a beach\n" +
            "Water gently lapping at your feet\n" +
            "But now you're sinking, what were you thinking?\n" +
            "That's all the time we have this week\n" +
            "Before the truth will set you free, it'll piss you off\n" +
            "Before you find a place to be, you're gonna lose the plot\n" +
            "Too late to tell you now, one ear and right out the other one\n" +
            "'Cause all you ever do is chant the same old mantra\n" +
            "And I know this doesn't make a lot of sense\n" +
            "But do you really wanna think about yourself now?\n" +
            "All I'm asking for's a little bit of faith\n" +
            "You know it's easy to believe\n" +
            "And I know this doesn't make a lot of sense\n" +
            "You know you gotta work the corners of your mind now\n" +
            "All I'm asking for's a little bit of faith\n" +
            "You know it's easy to, so easy to believe\n" +
            "Before the truth will set you free, it'll piss you off\n" +
            "Before you find a place to be, you're gonna lose the plot\n" +
            "Before the truth will set you free, it'll piss you off\n" +
            "Before you find a place to be, you're gonna lose the plot\n" +
            "Too late to tell you now, one ear and right out the other one\n" +
            "'Cause all you ever do is chant the same old mantra");
        
        Thread.sleep(2000);

        System.out.println("computer on");
    }
    
   public void turncOff() throws InterruptedException {
       
       ONNER = false;
       System.out.println("computer is shutting down");
       Thread.sleep(2000);
       
       System.out.println(""
            + "I wouldn't hold my breath if I was you\n" +
              "'Cause I'll forget but I'll never forgive you\n" +
              "Don't you know, don't you know?\n" +
              "True friends stab you in the front\n" +
              "It's funny how\n" +
              "Things work out\n" +
              "Such a bitter irony\n" +
              "Like a kick right to the teeth\n" +
              "It fell apart\n" +
              "Right from the start\n" +
              "But I couldn't even see\n" +
              "The forest for the trees\n" +
              "(I'm afraid you asked for this)\n" +
              "You got a lot of nerve\n" +
              "But not a lot of spine\n" +
              "You made your bed\n" +
              "When you worried about mine\n" +
              "This ends now\n" +
              "I wouldn't hold my breath if I was you\n" +
              "'Cause I'll forget but I'll never forgive you\n" +
              "Don't you know, don't you know?\n" +
              "True friends stab you in the front\n" +
              "I wouldn't hold my breath if I was you\n" +
              "You broke my heart and there's nothing you can do\n" +
              "And now you know, now you know\n" +
              "True friends stab you in the front\n" +
              "It's kind of sad\n" +
              "'Cause what we had\n" +
              "Well it could of been something\n" +
              "I guess it wasn't meant to be\n" +
              "So how dare you\n" +
              "Try and steal my flame\n" +
              "Just 'cause yours faded\n" +
              "Well hate is gasoline\n" +
              "A fire fueling all my dreams\n" +
              "(I'm afraid you asked for this)\n" +
              "You got a lot of nerve\n" +
              "But not a lot of spine\n" +
              "You made your bed\n" +
              "When you worried about mine\n" +
              "This ends now\n" +
              "I wouldn't hold my breath if I was you\n" +
              "'Cause I'll forget but I'll never forgive you\n" +
              "Don't you know, don't you know?\n" +
              "True friends stab you in the front\n" +
              "I wouldn't hold my breath if I was you\n" +
              "You broke my heart and there's nothing you can do\n" +
              "And now you know, now you know\n" +
              "True friends stab you in the front\n" +
              "You can run\n" +
              "But you can't hide\n" +
              "Time won't help you\n" +
              "'Cause karma has no deadline\n" +
              "You can run\n" +
              "But you can't hide\n" +
              "Time won't help you\n" +
              "'Cause karma has no deadline\n" +
              "I wouldn't hold my breath if I was you\n" +
              "'Cause I'll forget but I'll never forgive you\n" +
              "Don't you know, don't you know?\n" +
              "True friends stab you in the front\n" +
              "I wouldn't hold my breath if I was you\n" +
              "You broke my heart and there's nothing you can do\n" +
              "And now you know, now you know\n" +
              "True friends stab you in the front\n" +
              "And now you know, now you know\n" +
              "True friends stab you in the front\n" +
              "And now you know, now you know\n" +
              "True friends stab you in the front");
   }
   
   public boolean getcOn() {
       
       return ONNER;
   }
   
   ///////////////////////////////////
   
   public void printspecs() {

    System.out.println("casecorsair");
    System.out.println("ryzen7");
    System.out.println("rx5700");
    System.out.println("ramcorsair");
    System.out.println("asus");
    System.out.println("fanscorsair");
    System.out.println("seagate");
    System.out.println("crucial");
   }
    
}