package dussjavagraph;

import java.util.*;

public class DussGraphNode { 
   
    private int S;

    public DussGraphNode(int S) {
        
        this.S = S;
    }
    
    public DussGraphNode(DussGraphNode object) {
        
        this.S = object.getS();
    }

    public int getS() {
        
        return S;
    }

    public void setS(int S) {
        
        this.S = S;
    }
    
    public String toString() {
        
        
     return "Node_Content : " + S;
    }
    
}