import java.util.*;

public class BattagliaNavaleFunzionanteBrutto {
    
    public static int numRows = 10;
    public static int numCols = 10;
    public static int playerShips;
    public static int computerShips;
    public static String[][] griglia = new String[numR][numC];
    public static int[][] colpimissati = new int[numR][numC];

    public static void main(String[] args) {

        System.out.println("**************");
        System.out.println("**** helo ****");
        System.out.println("**************");
 
        CreaMappaOceano();

        NaviPlayer();

        NaviPC();

        do {

            Battle();

        }while(playerShips != 0 && computerShips != 0);

        gameOver();

    }

    public static void CreaMappaOceano(){
        //First section of Ocean Map
        System.out.print("  ");

        for(int i = 0; i < numC; i++)
                System.out.print(i);
        System.out.println();

        //Middle section of Ocean Map
        for(int i = 0; i < griglia.length; i++) {
            for (int j = 0; j < griglia[i].length; j++) {
                griglia[i][j] = " ";
                if (j == 0)
                    System.out.print(i + "|" + griglia[i][j]);
                else if (j == griglia[i].length - 1)
                    System.out.print(griglia[i][j] + "|" + i);
                else
                    System.out.print(griglia[i][j]);
            }
            System.out.println();
        }

        //Last section of Ocean Map
        System.out.print("  ");
        for(int i = 0; i < numC; i++)
            System.out.print(i);
        System.out.println();
    }

    public static void NaviPlayer(){
        Scanner input = new Scanner(System.in);

        System.out.println("\nPosiziona le tue navi:");
 
        playerShips = 5;
        for (int i = 1; i <= playerShips; ) {
            System.out.print("coordinate x per " + i + " navi: ");
            int x = input.nextInt();
            System.out.print("coordinate y per " + i + " navi: ");
            int y = input.nextInt();

            if((x >= 0 && x < numR) && (y >= 0 && y < numC) && (griglia[x][y] == " "))
            {
                griglia[x][y] =   "P";
                i++;
            }
            else if((x >= 0 && x < numR) && (y >= 0 && y < numC) && griglia[x][y] == "P")
            System.out.println(" non puoi mettere navi nello stesso punto ");
            else if((x < 0 || x >= numR) || (y < 0 || y >= numC))
                System.out.println("non puoi mettere navi fuori da " + numR + " a " + numC + " griglia");
        }
        stampamappaOceano();
    }

    public static void NaviPC(){
        System.out.println("\nPC METTE LE NAVI");
        //Deploying five ships for computer
        computerShips = 5;
        for (int i = 1; i <= computerShips; ) {
            int x = (int)(Math.random() * 10);
            int y = (int)(Math.random() * 10);

            if((x >= 0 && x < numR) && (y >= 0 && y < numC) && (griglia[x][y] == " "))
            {
                griglia[x][y] =   "C";
                System.out.println(i + ". NAVE INSERITA ");
                i++;
            }
        }
        stampamappaOceano();
    }

    public static void Battle(){
        playerTurn();
        computerTurn();

        stampamappaOceano();

        System.out.println();
        System.out.println("NAVI PLAYER: " + playerShips + " | NAVI PC: " + computerShips);
        System.out.println();
    }

    public static void playerTurn() {

        System.out.println("\nTUO TURNO");
        int x = -1, y = -1;

        do {

            final Scanner input = new Scanner(System.in);
            System.out.print("metti coordinate x: ");
            x = input.nextInt();
            System.out.print("metti coordinate y: ");
            y = input.nextInt();

            if ((x >= 0 && x < numR) && (y >= 0 && y < numC)) { // valido

                if (griglia[x][y] == "x") { // se la nave del player è gia li allora il player perde nave

                    System.out.println("hai distrutto una nave!");
                    griglia[x][y] = "!";
                    computerShips--;

                } else if (griglia[x][y] == "P") {

                    System.out.println("ti sei autodistrutto :(");
                    griglia[x][y] = "x";
                    playerShips--;

                } else if (griglia[x][y] == " ") {

                    System.out.println("missato");
                    griglia[x][y] = " ";

                }

            } else if ((x < 0 || x >= numR) || (y < 0 || y >= numC)) // non valido

                System.out.println("non puoi mettere navi fuori da " + numR + " a " + numC + " griglia");

        } while ((x < 0 || x >= numR) || (y < 0 || y >= numC)); // metti finche non fai giusto

    }

    public static void computerTurn() {

        System.out.println("\t TURNO PC");
        // indovina coordinate
        int x = -1, y = -1;

        do {

            x = (int)(Math.random() * 10);
            y = (int)(Math.random() * 10);

            if ((x >= 0 && x < numR) && (y >= 0 && y < numC)) { // good choice ! ez

                if (griglia[x][y] == "P") { // se la nave del pc è gia li allora il pc perde nave

                    System.out.println("PC TI HA AFFONDATO UNA NAVE");
                    griglia[x][y] = "x";
                    playerShips--;
                    

                } else if (griglia[x][y] == "C") {

                    System.out.println("PC SI è AUTOAFFONDATO UNA NAVE");
                    griglia[x][y] = "!";
                    computerShips--;
                }

                else if (griglia[x][y] == " ") {

                    System.out.println("PC MISSATO");
                                        // ricorda i tentativi failati del pc
                                        if(colpimissati[x][y] != 1)
                                        colpimissati[x][y] = 1;

                }

            }

        } while ((x < 0 || x >= numR) || (y < 0 || y >= numC)); // metti finche non fai giusto

    }

    public static void gameOver() {

        System.out.println("TUE NAVI: " + playerShips + " | NAVI PC: " + computerShips);

        if (playerShips > 0 && computerShips <= 0) {

            System.out.println(" U WIN :') ");

        }

        else {

            System.out.println(" U LOSE :'( ");

        }

    }

    public static void stampamappaOceano() {

        // prima sezione mappa
        System.out.println("");
    
        System.out.print(" | ");
        for (int i = 0; i < numC; i++) {
    
            System.out.print(i + "| ");
            System.out.print("");
    
        }
    
        System.out.println("");
        // sezione centrale mappa
        for (int x = 0; x < griglia.length; x++) {
    
            System.out.print(x + "|");
    
            for (int y = 0; y < griglia[x].length; y++) {
    
                System.out.print(griglia[x][y]);
                System.out.print(" ");
                System.out.print("|");
    
            }
    
            System.out.println("" + x);
    
        }
    
        // ultima sezione mappa
        System.out.print(" | ");
        for (int i = 0; i < numC; i++) {
    
            System.out.print(i + "| ");
    
        }
    
    }

        // ultima sezione mappa
        System.out.print(" | ");
        for (int i = 0; i < numC; i++) {

            System.out.print(i + "| ");

        }

    }
}
