package dussjavagraph;

import java.io.*;
import java.util.*;
import java.util.Scanner;

/*



*/

public class DussGraphWeights {

    Scanner scmatrix = new Scanner(System.in);

    private int weights;

    public DussGraphWeights(int weights) 
    {
        
        this.weights = weights;
    }

    public DussGraphWeights(DussGraphWeights object) 
    {
        
        this.weights = object.getWeights();
    }

    public int getWeights() 
    {

        return weights;
    }

    public void setWeights(int weights) 
    {
        this.weights = weights;
    }

    public String toString() 
    {

        return "weight of the node ->" + weights;
    }

}
