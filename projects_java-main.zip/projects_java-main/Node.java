package happyb;

public class Node {

    private invitati info;
    private Node link;

    public Node (invitati persona){

        info = new invitati(persona);
        link = null;
    }

    public invitati getInfo() {
        
        return new invitati(info);
    }

    public void setInfo(invitati persona) {
        
        this.info = new invitati(persona);
    }

    public Node getLink() {
        
        return link;
    }

    public void setLink(Node link) {
        
        this.link = link;
    }
}
