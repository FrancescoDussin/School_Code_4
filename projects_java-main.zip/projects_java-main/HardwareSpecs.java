package devices;

public interface HardwareSpecs extends SpecsPrinter{

}
