package happyb;

public class invitati {
    
    private String Name;
    private String Sex;
    private int NumT;
    private char Accepted;

    public invitati (String Name, String Sex, int NumT, char Accepted) {

        this.Name = Name;
        this.Sex = Sex;
        this.NumT = NumT;
        this.Accepted = Accepted;
    }

    public invitati (invitati persona) {
        
        this.Name = persona.getName();
        this.Sex = persona.getSex();
        this.NumT = persona.getNumT();
        this.Accepted = persona.getAccepted();
    }

    public String getName() {

        return Name;
    }

    public void setName(String Name) {

        this.Name = Name;
    }

    public String getSex() {

        return Sex;
    }

    public void setSex(String Sex) {
        
        this.Sex = Sex;
    }

    public int getNumT() {
        
        return NumT;
    }

    public void setNumT(int NumT) {
        
        this.NumT = NumT;
    }
    
    public char getAccepted() {
        
        return Accepted;
    }
    
    public void setAccepted() {
        
        this.Accepted = Accepted;
    }
 
    public String toString() {
        
        return "\t"+Name+"\t"+Sex+"\t"+NumT+"\n" ; 
    }

}
