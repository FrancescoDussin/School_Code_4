package happyb;

import java.util.Scanner;

public class festa{

        public static void main(String []args) {

        Scanner searching = new Scanner(System.in);
        String search;

        Happyb list = new Happyb();

        invitati inv1 = new invitati ("abc","fff", 56, 'y');
        invitati inv2 = new invitati("def","mmm", 34, 'y');
        invitati inv3 = new invitati("ghi","fmf", 12, 'n');
        invitati inv4 = new invitati("jkl", "mfm", 789, 'n');
        invitati inv5 = new invitati("mno", "ffm", 456, 'y');
        invitati inv6 = new invitati("pqr", "mff", 123, 'y');

        System.out.println("name");
        search = searching.nextLine();
        list.ricercarobaname(search);
        System.out.println(list.ricercarobaname(search));
        
        System.out.println("sex");
        search = searching.nextLine();
        list.ricercarobasex(search);
        System.out.println(list.ricercarobasex(search));
        
        System.out.println("cell");
        search = searching.nextLine();
        list.ricercarobacell(search);
        System.out.println(list.ricercarobacell(search));
        
        list.hasAccepted('e');
  }
}
/*
        list.headAdding(inv1);
        list.headAdding(inv2);
        list.headAdding(inv6);
        list.tailAdding(inv6);
        list.tailAdding(inv6);
        list.tailAdding(inv1);
*/