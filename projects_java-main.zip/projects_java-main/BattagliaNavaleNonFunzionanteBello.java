import java.util.*;

public class BattagliaNavaleNonFunzionanteBello {
    
    public static int numR = 10;
    public static int numC = 10;
    public static int playerShips;
    public static int computerShips;
    public static String[][] griglia = new String[numR][numC];
    public static int[][] missedGuesses = new int[numR][numC];
    public static String[][] grigliaPC = new String[numR1][numC1];


    public static void main(final String[] args){

        System.out.println("**************");
        System.out.println("**** helo ****");
        System.out.println("**************");

        // MappaMare
        createOceanMap();

        // InserireNaviPLAYER
        deployPlayerShips();

        // InserireNaviPC
        deployComputerShips();

        // 1v1Fag
       do {

            Battle();
            
        }while(playerShips != 0 && computerShips != 0);

        // Fine
        gameOver(); 

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    

    public static void createOceanMap() {
        //sezione prima mappa
        System.out.print(" |");
        for(int i = 0; i < numC; i++) {

                System.out.print(i + "|");
                System.out.print("");

        }

        System.out.println("");
        //sezione centrale mappa
        for(int i = 0; i < griglia.length; i++) {
            

            for (int j = 0; j < griglia[i].length; j++) {

                griglia[i][j] = " ";

                if (j == 0)

                    System.out.print(i + "|" + griglia[i][j]);

                else if (j == griglia[i].length - 1)
                    System.out.print(griglia[i][j] + "|" + i);

                else
                    System.out.print(griglia[i][j]+"|");

            }

            System.out.println();

        }

        // ultima sezione mappa
        System.out.print(" |");
        for(int i = 0; i < numC; i++){

            System.out.print(""+i + "|");
            System.out.print("");

        }

    }
    

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    

    public static void deployPlayerShips() {

   //nave4pl
   //nave3pl
   //nave2pl
   //nave1pl

        final Scanner input = new Scanner(System.in);

        System.out.println("DIMMI LA DIMENSIONE DELLA NAVE");
        dimensionenave = dt.nextInt();

        if ((dimensionenave >= 1) && (dimensionenave < 5)) {
            switch (dimensionenave) {   

                case 1: 

                        System.out.println("VERSO-inserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                        int verso1 = input.nextInt();

                        while(verso1 == 1 || verso1 == 0){

                            System.out.println("VERSO-reinserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                            verso1 = input.nextInt();

                        }

                        System.out.print("coordinate x per navi: ");
                        final int x1 = input.nextInt();

                        System.out.print("coordinate y per navi: ");
                        final int y1 = input.nextInt();

                        if((x1 >= 0 && x1 < numR) && (y1 >= 0 && y1 < numC) && (griglia[x1][y1] == " ")) {

                            griglia[x1][y1] =   "P";
                            //

                        }

                        else if((x1 >= 0 && x1 < numR) && (y1 >= 0 && y1 < numC) && griglia[x1][y1] == "P") {

                            System.out.println(" non puoi mettere navi nello stesso punto ");
        
                        }

                        else if((x1 < 0 || x1 >= numR) || (y1 < 0 || y1 >= numC)) {

                            System.out.println("non puoi mettere navi fuori da" + numR + " a " + numC + " griglia");

                        }
        
                        navepl1(griglia, verso1,  numR,  numC); 

                        printOceanMap();

                        break;

                        case 2: 

                        System.out.println("VERSO-inserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                        int verso2 = input.nextInt();

                        while(verso2 == 1 || verso2 == 0) {

                            System.out.println("VERSO-reinserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                            verso2 = input.nextInt();

                        }

                        System.out.print("coordinate x per navi: ");
                        final int x2 = input.nextInt();

                        System.out.print("coordinate y per navi: ");
                        final int y2 = input.nextInt();

                        if((x2 >= 0 && x2 < numR) && (y2 >= 0 && y2 < numC) && (griglia[x2][y2] == " ")) {

                            griglia[x2][y2] =   "P";
                            //

                        }
                        else if((x2 >= 0 && x2 < numR) && (y2 >= 0 && y2 < numC) && griglia[x2][y2] == "P") {

                        System.out.println(" non puoi mettere navi nello stesso punto ");

                        }
        
                    else if((x2 < 0 || x2 >= numR) || (y2 < 0 || y2 >= numC)) {

                        System.out.println("non puoi mettere navi fuori da" + numR + " a " + numC + " griglia");

                    }
        
                

                        navepl2(griglia, verso2,  numR,  numC); 

                        printOceanMap();

                        break;  
                        
                        case 3: 

                        System.out.println("VERSO-inserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                        int verso3 = input.nextInt();

                        while(verso3 == 1 || verso3 == 0){

                            System.out.println("VERSO-reinserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                            verso3 = input.nextInt();

                        }

                        System.out.print("coordinate x per navi: ");
                        final int x3 = input.nextInt();

                        System.out.print("coordinate y per navi: ");
                        final int y3 = input.nextInt();

                        if((x3 >= 0 && x3 < numR) && (y3 >= 0 && y3 < numC) && (griglia[x3][y3] == " ")) {

                            griglia[x3][y3] =   "P";
                            //

                        }

                        else if((x3 >= 0 && x3 < numR) && (y3 >= 0 && y3 < numC) && griglia[x3][y3] == "P") {

                        System.out.println(" non puoi mettere navi nello stesso punto ");

                        }
        
                    else if((x3 < 0 || x3 >= numR) || (y3 < 0 || y3 >= numC)) {

                        System.out.println("non puoi mettere navi fuori da" + numR + " a " + numC + " griglia");

                    }
        
                        navepl3(griglia, verso3,  numR,  numC); 

                        printOceanMap();

                        break; 

                        case 4: 

                        System.out.println("VERSO-inserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                        int verso4 = input.nextInt();

                        while(verso4 == 1 || verso4 == 0){

                            System.out.println("VERSO-reinserisci 1 se lo vuoi verticale o 0 se lo vuoi orizzontale");
                            verso4 = input.nextInt();

                        }

                        System.out.print("coordinate x per navi: ");
                        final int x4 = input.nextInt();

                        System.out.print("coordinate y per navi: ");
                        final int y4 = input.nextInt();

                        if((x4 >= 0 && x4 < numR) && (y4 >= 0 && y4 < numC) && (griglia[x4][y4] == " ")) {

                            griglia[x4][y4] =   "P";
                            //

                        }

                        else if((x4 >= 0 && x4 < numR) && (y4 >= 0 && y4 < numC) && griglia[x4][y4] == "P") {

                            System.out.println(" non puoi mettere navi nello stesso punto ");

                        }
        
                        else if((x4 < 0 || x4 >= numR) || (y4 < 0 || y4 >= numC)) {

                            System.out.println("non puoi mettere navi fuori da" + numR + " a " + numC + " griglia");

                        }

                        navepl4(griglia, verso4,  numR,  numC);
                        
                        printOceanMap();

                        break; 

                }

            }

        }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public static void deployComputerShips() {

        System.out.println("\nPC METTE LE NAVI");
        //mette 5 navi
        computerShips = 5;

        final int DIMENSIONE = (int)(Math.random() * 2-0);

        if ((DIMENSIONE >= 1) && (DIMENSIONE < 5)) {
            switch (DIMENSIONE) {   

                case 1: 

                        nave1pc(griglia);

                        printOceanMap();

                    break;

                case 2: 

                        nave2pc(griglia); 

                        printOceanMap();

                    break;  
                        
                case 3: 

        
                        nave3pc(griglia); 

                        printOceanMap();

                    break; 

                case 4:

                        nave4pc(griglia);
                        
                        printOceanMap();

                    break; 

                }

            }

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public static void Battle() {

        playerTurn();
        computerTurn();

        printOceanMap();

        System.out.println();
        System.out.println("NAVI PLAYER: " + playerShips + " | NAVI PC: " + computerShips);
        System.out.println();

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public static void playerTurn(){

        System.out.println("\nTUO TURNO");
        int x = -1, y = -1;

        do {

            final Scanner input = new Scanner(System.in);
            System.out.print("metti coordinate x: ");
            x = input.nextInt();
            System.out.print("metti coordinate y: ");
            y = input.nextInt();

            if ((x >= 0 && x < numR) && (y >= 0 && y < numC)) { // valido

                if (griglia[x][y] == "x") { // se la nave del player è gia li allora il player perde nave

                    System.out.println("hai distrutto una nave!");
                    griglia[x][y] = "!"; // hittato ma non tutto
                    BattleShipsC--;

                }
                else if (griglia[x][y] == "P") {

                    System.out.println("ti sei autodistrutto :(");
                    griglia[x][y] = "x";
                    playerShips--;

                }
                else if (griglia[x][y] == " ") {

                    System.out.println("missato");
                    griglia[x][y] = "-";

                }

            }
            else if ((x < 0 || x >= numR) || (y < 0 || y >= numC))  // non valido

                System.out.println("non puoi mettere navi fuori da " + numR + " a " + numC + " griglia");

        }while((x < 0 || x >= numR) || (y < 0 || y >= numC));  // metti finche non fai gud

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    public static void computerTurn(){

        System.out.println("\t TURNO PC");
        // indovina coordinate
        int x = -1, y = -1;

        do {

            x = (int)(Math.random() * 10);
            y = (int)(Math.random() * 10);

            if ((x >= 0 && x < numR) && (y >= 0 && y < numC)) { // good choice ! ez 

                if (griglia[x][y] == "@") { // se la nave del pc è gia li allora il pc perde nave

                    System.out.println("PC TI HA AFFONDATO UNA NAVE");
                    griglia[x][y] = "x";
                    playerShips--;
//public static String[][] grigliaPC = new String[numR][numC];
                }
                else if (griglia[x][y] == "x") {

                    System.out.println("PC SI è AUTOAFFONDATO UNA NAVE");
                    griglia[x][y] = "!";
                    computerShips--;
                }
//public static String[][] grigliaPC = new String[numR][numC];
                else if (griglia[x][y] == " ") {

                    System.out.println("PC MISSATO");
                    // ricorda i tentativi failati del pc
                    if(missedGuesses[x][y] != 1)
                        missedGuesses[x][y] = 1;
//public static String[][] grigliaPC = new String[numR][numC];
                }

            }

        }while((x < 0 || x >= numR) || (y < 0 || y >= numC));  // metti finche non fai gud

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public static void gameOver() {

        System.out.println("TUE NAVI: " + playerShips + " | NAVI PC: " + computerShips);

        if(BattleShipsP > 0 && BattleShipsC <= 0) {

            System.out.println(" U WIN myroger :)");

            }

            else {

            System.out.println("u lose");

            }

   }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

public static void printOceanMap() {

    // prima sezione mappa
    System.out.println("");

    System.out.print(" | ");
    for (int i = 0; i < numC; i++) {

        System.out.print(i + "| ");
        System.out.print("");

    }

    System.out.println("");
    // sezione centrale mappa
    for (int x = 0; x < griglia.length; x++) {

        System.out.print(x + "|");

        for (int y = 0; y < griglia[x].length; y++) {

            System.out.print(griglia[x][y]);
            System.out.print(" ");
            System.out.print("|");

        }

        System.out.println("" + x);

    }

    // ultima sezione mappa
    System.out.print(" | ");
    for (int i = 0; i < numC; i++) {

        System.out.print(i + "| ");

    }

}

public static void printOceanMapPC() {

    // prima sezione mappa
    System.out.println("");

    System.out.print(" | ");
    for (int i = 0; i < numC; i++) {

        System.out.print(i + "| ");
        System.out.print("");

    }

    System.out.println("");
    // sezione centrale mappa
    for (int x = 0; x < grigliaPC.length; x++) {

        System.out.print(x + "|");

        for (int y = 0; y < grigliaPC[x].length; y++) {

            System.out.print(grigliaPC[x][y]);
            System.out.print(" ");
            System.out.print("|");

        }

        System.out.println("" + x);

    }

    // ultima sezione mappa
    System.out.print(" | ");
    for (int i = 0; i < numC; i++) {

        System.out.print(i + "| ");

    }

}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 public static void nave4pl(final int griglia[][] , final int verso4 , int numR , int numC) {

        final int lunghezza = 5;

        if(verso4 == 1) {  //ver

            for(int i = numC ; i < lunghezza ; i++) {

                numC++;
                griglia[numR][numC] = 1;

            }

        }

        else {  //ori

            for(int i = numR ; i < lunghezza ; i++) {

                numR++;
                griglia[numR][numC] = 1;

            }

        }

    }

    public static void nave3pl(final int griglia[][] , final int verso3 , int numR , int numC) {

        final int lunghezza = 4;

        if(verso3 == 1) {  //ver

            for(int i = numC ; i < lunghezza ; i++) {

                numC++;
                griglia[numR][numC] = 1;

            }

        }

        else { //ori

            for(int i = numR ; i < lunghezza ; i++) {

                numR++;
                griglia[numR][numC] = 1;

            }

        }

    }

    public static void nave2pl(final int griglia[][] , final int verso2 , int numR , int numC) {

        final int lunghezza = 3;

        if(verso2 == 1) {  //ver

            for(int i = numC ; i < lunghezza ; i++) {

                numC++;
                griglia[numR][numC] = 1;

            }

        }

        else {  //ori

            for(int i = numR ; i < lunghezza ; i++) {  

                numR++;
                griglia[numR][numC] = 1;

            }

        }

    }

        public static void nave1pl(final int griglia[][] , final int verso1 , int numR , int numC) {

        final int lunghezza = 2;

        if(verso1 == 1) { //ver

            for(int i = numC ; i < lunghezza ; i++) {

                numC++;
                griglia[numR][numC] = 1;
            
            }
        }

        else {  //ori

            for(int i = numR ; i < lunghezza ; i++) {

                numR++;
                griglia[numR][numC] = 1;

            }

        }

    }

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public static void nave3pc(final string griglia[][]) {

        System.out.println("\nPC METTE LE NAVI");
        //mette 5 navi
        playerShips = 5;

        for (int j = 1; j <= computerShips; j++ ) {

        final int rand3 = (int)(Math.random()*2);
        int nRiga3 = (int)(Math.random()*10);
        final int lunghezzaR = nRiga3 + 3;
        int nCol3 = (int)(Math.random()*10);
        final int lunghezzaC = nCol3 + 3;

        if(rand3 == 0) { //ver

            while(matr[nRiga3][nCol3] == 1) {

                nCol3= (int)(Math.random()*10);

            }

            while(lunghezzaR > 9) {

                nRiga3 = (int)(Math.random()*10);

            }

            for(int i = nRiga3 ; i < lunghezzaR ; i++) {

                nRiga3++;
                matr[nRiga3 - 1][nCol3] = 1;

            }

        }

        else { //ori

            while(matr[nRiga3][nCol3] == 1) {

                nRiga3 = (int)(Math.random()*10);

            }

            while(lunghezzaC > 9) {

                nCol3= (int)(Math.random()*10);

            }

            for(int i = nCol3 ; i < lunghezzaC ; i++) {

                nCol3++;
                matr[nRiga3][nCol3-1] = 1;

            }

        }
        
      }

    }

    public static void nave4pc(final String griglia[][]) {

        System.out.println("\nPC METTE LE NAVI");
        //mette 5 navi
        playerShips = 5;

        for (int j = 1; j <= computerShips; j++ ) {


        final int rand4 = (int)(Math.random()*2);
        int nRiga4 = (int)(Math.random()*10);
        final int lunghezzaR = nRiga4 + 4;
        int nCol4 = (int)(Math.random()*10);
        final int lunghezzaC = nCol4 + 4;

        if(rand4 == 0) { //ver

            while(matr[nRiga4][nCol4] == 1) {

                nCol4 = (int)(Math.random()*10);

            }

            while(lunghezzaR > 9) {

                nRiga4 = (int)(Math.random()*10);

            }

            for(int i = nRiga4 ; i < lunghezzaR ; i++) {

                nRiga4++;
                matr[nRiga4 - 1][nCol4] = 1;

            }

        }

        else {  //ori

            while(matr[nRiga4][nCol4] == 1) {

                nRiga4 = (int)(Math.random()*10);

            }

            while(lunghezzaC > 9) {

                nCol4 = (int)(Math.random()*10);

            }

            for(int i = nCol4 ; i < lunghezzaC ; i++) {

                nCol4++;
                matr[nRiga4][nCol4-1] = 1;

            }

        }

      }

    }

    public static void nave1pc(final String griglia[][]) {

        System.out.println("\nPC METTE LE NAVI");
        //mette 5 navi
        playerShips = 5;

        for (int j = 1; j <= computerShips; j++ ) {

        final int rand1 = (int)(Math.random()*2);
        int nRiga1 = (int)(Math.random()*10);
        final int lunghezzaR = nRiga1 + 4;
        int nCol1 = (int)(Math.random()*10);
        final int lunghezzaC = nCol1 + 4;

        if(rand1 == 0) { //ver

            while(matr[nRiga1][nCol1] == 1) {

                nCol1 = (int)(Math.random()*10);

            }

            while(lunghezzaR > 9) {

                nRiga1 = (int)(Math.random()*10);

            }

            for(int i = nRiga1 ; i < lunghezzaR ; i++) {

                nRiga1++;
                matr[nRiga1 - 1][nCol1] = 1;

            }

        }

        else {  //ori

            while(matr[nRiga1][nCol1] == 1) {

                nRiga1 = (int)(Math.random()*10);

            }

            while(lunghezzaC > 9) {

                nCol1 = (int)(Math.random()*10);

            }

            for(int i = nCol1 ; i < lunghezzaC ; i++) {

                nCol1++;
                matr[nRiga1][nCol1-1] = 1;

            }

        }

    }

  }

  public static void nave2pc(final String griglia[][]) {

    System.out.println("\nPC METTE LE NAVI");
    //mette 5 navi
    playerShips = 5;

    for (int j = 1; j <= computerShips; j++ ) {

    final int rand2 = (int)(Math.random()*2);
    int nRiga2 = (int)(Math.random()*10);
    final int lunghezzaR = nRiga2 + 4;
    int nCol2 = (int)(Math.random()*10);
    final int lunghezzaC = nCol2 + 4;

    if(rand2 == 0) { //ver

        while(matr[nRiga2][nCol2] == 1) {

            nCol2 = (int)(Math.random()*10);

        }

        while(lunghezzaR > 9) {

            nRiga2 = (int)(Math.random()*10);

        }

        for(int i = nRiga2 ; i < lunghezzaR ; i++) {

            nRiga2++;
            matr[nRiga2 - 1][nCol2] = 1;

        }

    }

    else {  //ori

        while(matr[nRiga2][nCol2] == 1) {

            nRiga2 = (int)(Math.random()*10);

        }

        while(lunghezzaC > 9) {

            nCol2 = (int)(Math.random()*10);

        }

        for(int i = nCol2 ; i < lunghezzaC ; i++) {

            nCol2++;
            matr[nRiga2][nCol2-1] = 1;

        }

     }

   }

  }

}