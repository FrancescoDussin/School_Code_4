package retard;

import javax.swing.*; 
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.event.*;  
import java.awt.*;
import java.beans.*;
import java.util.*;

public class guicode1 extends JFrame implements ActionListener
{

    JFrame frame;
    JPanel panel;
    JLabel label, label_1, label_2, label_3;
    JTextArea userText_1, userText_2, outputText_1;
    JButton button, butter;

    guicode1()
    {
        JLabel label_1 = new JLabel("calc-1");
        label_1.setBounds(60,20,100,25);
        add(label_1);

        JLabel label_2 = new JLabel("calc-2");
        label_2.setBounds(60, 60, 100, 25);
        add(label_2);

        JLabel label_3 = new JLabel("result");
        label_3.setBounds(60, 100, 100, 25);
        add(label_3);

        JTextArea userText_1 = new JTextArea();
        userText_1.setBounds(120,20,100,25);
        userText_1.setBackground(Color.PINK);
        add(userText_1);

        JTextArea userText_2 = new JTextArea();
        userText_2.setBounds(120,60,100,25);
        userText_2.setBackground(Color.PINK);
        add(userText_2);

        JTextArea outputText_1 = new JTextArea();
        // textArea = new JTextArea(5, 40);
        outputText_1.setBounds(120, 100, 100, 25);
        add(outputText_1);

        //setLayout(new FlowLayout());
    }

    public void ActionListener(ActionEvent e) 
    {
        butter = new JButton("calculate");
        frame.add(butter, BorderLayout.SOUTH);
        frame.pack();
        butter.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        int gay_bizzy;
        int gay_coomer;
        int total_sex;

        gay_bizzy = Integer.parseInt(userText_1.getText());
        gay_coomer = Integer.parseInt(userText_2.getText());

        total_sex = gay_coomer + gay_bizzy;
        outputText_1.setText("" + total_sex);
        // String.valueOf(total_sex));
        // ("" + total_sex);
    }
    
    public static void main(String[] args) 
    {
        /*
         * private javax.swing.JButton NAME; // declaration
         * 
         * .setBounds(10, 20, 30, 40);
         * 
         * 10 = x 20 = y 30 = width 40 = height
         */

        guicode1 obj = new guicode1();
        obj.setSize(500, 300);
        obj.setBackground(Color.BLUE);
        obj.setVisible(true);

        /*
        frame.setSize(300, 200);
        frame.setVisible(true);
        frame.add(panel);
        panel.setLayout(null);
        */
    }
}
