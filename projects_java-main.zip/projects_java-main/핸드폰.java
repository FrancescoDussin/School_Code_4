package devices;

public class 핸드폰 { //cellphone

}
