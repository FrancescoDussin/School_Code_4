package dussjavagraph;

/*
adding an edge
removing an edge
check if 2 nodes are connected together
*/

public class DussGraphMethods {

    private int Num_Vertices;
    private int Graph_Matrix[][];

    public DussGraphMethods() 
    {

    }

    public DussGraphMethods(int Num_Vertices) 
    {
        this.Num_Vertices = Num_Vertices;
        Graph_Matrix = new int[Num_Vertices][Num_Vertices];
    }
    
    public int getNum_Vertices() 
    {
        return Num_Vertices;
    }

    public void setNum_Vertices(int num_Vertices) 
    {
        Num_Vertices = num_Vertices;
    }

    public int[][] getGraph_Matrix() 
    {
        return Graph_Matrix;
    }

    public void setGraph_Matrix(int[][] graph_Matrix) 
    {
        Graph_Matrix = graph_Matrix;
    }

    public void Graph_Edge_Adder(int New_Edge_colums, int New_Edge_Lines) 
    {
        Graph_Matrix[New_Edge_colums][New_Edge_Lines] = 1;
    }

    public void Graph_Edge_Remover(int Remove_Edge_colums, int Remove_Edge_Lines) 
    {
        Graph_Matrix[Remove_Edge_colums][Remove_Edge_Lines] = 0;
    }
}

/*
 * @Override public int hashCode() { final int prime = 31; int result = 1;
 * result = prime * result + Arrays.deepHashCode(Graph_Matrix); result = prime *
 * result + Num_Vertices; return result; }
 * 
 * @Override public boolean equals(Object obj) { if (this == obj) return true;
 * if (obj == null) return false; if (getClass() != obj.getClass()) return
 * false; DussGraphMethods other = (DussGraphMethods) obj; if
 * (!Arrays.deepEquals(Graph_Matrix, other.Graph_Matrix)) return false; if
 * (Num_Vertices != other.Num_Vertices) return false; return true; }
 */
