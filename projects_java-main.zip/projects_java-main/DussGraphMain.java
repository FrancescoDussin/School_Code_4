package dussjavagraph;

import java.io.*;
import java.util.*;
import java.util.Scanner;

/*

grafo orientato
gli archi indicano anche il verso ( hai solo strade a senso unico )
grafo non orientato
gli archi indicano solo la direzione ( strada a doppio senso )

Implementa un programma Java che prevede la costruzione di una class Grafo: a partire dalla matrice
delle adiacenze che si trova in un file, istanziare gli oggetti Nodo e Arco per costruire il Grafo.
Prevedere l'operazione che dato in input due nodi indichi se esiste l'arco incidente.

*/

public class DussGraphMain {

    public static void main(String args[]) {

        Scanner scmain = new Scanner(System.in);

        DussGraphMethods Graph_OBJ = new DussGraphMethods(10);

        Graph_OBJ.Graph_Edge_Adder(0, 0);
        Graph_OBJ.Graph_Edge_Adder(0, 1);
        Graph_OBJ.Graph_Edge_Adder(0, 2);
        Graph_OBJ.Graph_Edge_Adder(1, 2);
        Graph_OBJ.Graph_Edge_Adder(2, 0);
        Graph_OBJ.Graph_Edge_Adder(2, 3);

    /*
    ( matrice di adiacenza )

    X-0-1-2
    0|1-0-1
    1|1-0-0
    2|1-1-0
    3|0-0-1
    */
    }
}
