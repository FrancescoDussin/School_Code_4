package devices;

public class 태블릿 { // tablet

}
