package dussfileheap;

import java.util.*;

public class DussHeapMethods {

    int[] arr_heap = new int[5];

    Scanner scc = new Scanner(System.in);
    
    private DussHeapNode data;
    private DussHeapMethods left;
    private DussHeapMethods right;
    
    public DussHeapMethods() {
        
    }
    
    public DussHeapMethods(DussHeapNode mury) {
        
        this.data = new DussHeapNode(mury);
        this.left = null;
        this.right = null;
    }
    
    public DussHeapMethods(DussHeapMethods kpop) {
        
        this.data = kpop.getData();
        this.left = kpop.getLeft();
        this.right = kpop.getRight();
    }

    public DussHeapNode getData() {
        
        return data;
    }

    public void setData(DussHeapNode data) {
        
        this.data = data;
    }

    public DussHeapMethods getLeft() {
        
        return left;
    }

    public void setLeft(DussHeapMethods left) {
        
        this.left = left;
    }

    public DussHeapMethods getRight() {
        
        return right;
    }

    public void setRight(DussHeapMethods right) {
        
        this.right = right;
    }
}