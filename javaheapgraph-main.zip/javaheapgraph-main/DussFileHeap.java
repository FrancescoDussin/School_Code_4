package dussfileheap;

////////////////////////////////////////////////////////

import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/////////////////////////////////////////////////////////
/*
MAX HEAP MIN HEAP - STEPS

-write strings into a file
-checker: divive each string with ;
-read string from file and put it into the array of string
-sort them in order (MAX - MIN HEAP)
-add insert method ( write string into a )
-
-

*/
/////////////////////////////////////////////////////////

public class DussFileHeap {
  public static void main(String[] args) {

    //int[] arr_heap = new int[5];to 
    int[] arr_heap = new int[10];

    File filetxtinfo = new File("C:\\Users\\Admin\\Desktop\\VSCODEFILES\\dussfileheap\\DussHeapNote.txt");

    if (filetxtinfo.exists()) {

      System.out.println("----------------------------------------------");

      System.out.println("File name: " + filetxtinfo.getName());
      System.out.println("Absolute path: " + filetxtinfo.getAbsolutePath());
      System.out.println("Writeable: " + filetxtinfo.canWrite());
      System.out.println("Readable " + filetxtinfo.canRead());
      System.out.println("File size in bytes " + filetxtinfo.length());
    } else {

      System.out.println("The file does not exist.");
    }

    try {

      FileWriter filetxtwriter = new FileWriter(
          "C:\\Users\\Admin\\Desktop\\VSCODEFILES\\dussfileheap\\DussHeapNote.txt");

        int i = 0;

          String[] aa = new String[] {"1", "12", "123,", "1234,", "12345,", "123456,", "1234567,", "12345678,", "123456789,", "1234567890,"};

          for(i = 0; i < aa.length; i++) {

            filetxtwriter.write(aa[i]);
            filetxtwriter.close();

          }

        Scanner skans = new Scanner(new File(
          "C:\\Users\\Admin\\Desktop\\VSCODEFILES\\dussfileheap\\DussHeapNote.txt"));

        for(i = 0; i < 10; i++) {// '\0'

          if(aa[i] == "," || aa[i] == "\n") {

            i++;
          } //end if
        }

        while (skans.hasNextInt()) {

          arr_heap[i++] = skans.nextInt();
        }

        for (i = 0; i < 10; i++) {

          System.out.println(arr_heap[i]);
        }
/*
          for(i = 0; i < 5; i++) {
              filetxtwriter.write(arr_heap[i] + "\n");

              filetxtwriter.flush();
          }
*/   /*
          if() {


          }
*/

    } catch (IOException e) {

      System.out.println("An error occurred.");
      e.printStackTrace();
    }

    try {

      File filetxtreader = new File(
          "C:\\Users\\Admin\\Desktop\\VSCODEFILES\\dussfileheap\\DussHeapNote.txt");

      Scanner myReader = new Scanner(filetxtreader);

      while (myReader.hasNextLine()) {

        String data = myReader.nextLine();
        System.out.println(data);
      }

      myReader.close();

    } catch (FileNotFoundException e) {

      System.out.println("errore");
      e.printStackTrace();
    }

    
  }
}