package dussjavagraph;

public class DussGraphMethods {
    
    private int[][] TDArr = new int[5][5];
    private DussGraphWeights weights;

    public DussGraphMethods(int[][] tDArr, DussGraphWeights weights) 
    {
        weights = new DussGraphWeights(weights);
        TDArr = tDArr;
    }

    public DussGraphMethods(DussGraphWeights mury) 
    {
        this.weights = new DussGraphWeights(mury);
    }

    public void setTDarr(int[][] TDArr) 
    {
        TDArr = TDArr;
    }

    public int[][] getTDArr() 
    {
        return TDArr;
    }

    public DussGraphWeights getWeights() 
    {
        return weights;
    }

    public void setWeights(DussGraphWeights weights) 
    {
        this.weights = weights;
    }

    


}
