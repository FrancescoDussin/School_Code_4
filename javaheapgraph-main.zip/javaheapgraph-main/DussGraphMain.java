package dussjavagraph;

import java.io.*;
import java.util.*;
import java.util.Scanner;

public class DussGraphMain {

    Scanner scmain = new Scanner(System.in);

    //weights class
    DussGraphWeights DGM_1 = new DussGraphWeights(2);
    DussGraphWeights DGM_2 = new DussGraphWeights(3);
    DussGraphWeights DGM_3 = new DussGraphWeights(4);
    DussGraphWeights DGM_4 = new DussGraphWeights(5);
    DussGraphWeights DGM_5 = new DussGraphWeights(6);

    DussGraphMethods ROOT = new DussGraphMethods(DGM_1);
    DussGraphMethods SUB1 = new DussGraphMethods(DTM2);
    DussGraphMethods SUB2 = new DussGraphMethods(DTM3);
    DussGraphMethods SUB3 = new DussGraphMethods(DTM4);
    DussGraphMethods SUB4 = new DussGraphMethods(DTM5);
    
}
